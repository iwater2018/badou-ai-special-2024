from src import detect_faces, show_bboxes
from PIL import Image

image = Image.open('images/example.png')
bounding_boxes, landmarks = detect_faces(image)
show_bboxes(image, bounding_boxes, landmarks)